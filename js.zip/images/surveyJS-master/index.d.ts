
declare module 'surveyjs';
